from server import serve

if __name__ == "__main__":
    serve(port=2334,passwd="1231",back_end_url="http://127.0.0.1")
